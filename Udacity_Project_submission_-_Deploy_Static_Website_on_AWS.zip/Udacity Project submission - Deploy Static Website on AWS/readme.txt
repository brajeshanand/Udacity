This is the readme.txt file for my project submission of "Deploy Static Website on AWS".

All the relevant screenshots of each step have been provided in a separate doc file named "Udacity Project submission - Deploy Static Website on AWS.doc"

Below is the website's URL.

http://brajeshudacity1.1.s3-website-us-east-1.amazonaws.com/


FYI please, Just to do some customization, I have changed the background image with the one that I clicked personally, and I have changed the website’s front page title to “Brajesh’s Travel Blog”.